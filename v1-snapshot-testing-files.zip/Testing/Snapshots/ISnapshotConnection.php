<?php

namespace App\Domain\Testing\Snapshots;

use Illuminate\Database\ConnectionInterface;

interface ISnapshotConnection
{
	/**
	 * @return ConnectionInterface
	 */
	public function getDatabase(): ConnectionInterface;

	/**
	 * @return static
	 */
	public function refreshDatabase(): static;

	/**
	 * @param  IDatabaseSnapshot  $databaseSnapshot
	 *
	 * @return static
	 */
	public function refreshConnection(IDatabaseSnapshot $databaseSnapshot): static;

	/**
	 * @param  string|ConnectionInterface  $connection
	 * @param  bool  $isSQLiteConnection
	 *
	 * @return static
	 */
	public function setDatabase(string|ConnectionInterface $connection, bool $isSQLiteConnection = true): static;
}

<?php

namespace App\Domain\Testing\Snapshots\Scenarios;

use App\Domain\Testing\Snapshots\AllSchedulesAreValid\April14ToAugust31StartingIn2022 as AllValidFromApril14th2022toAugust31st2022;
use App\Domain\Testing\Snapshots\DishMySqlSnapshotConnection;
use App\Domain\Testing\Snapshots\IDatabaseSnapshot;
use Carbon\CarbonImmutable;
use Illuminate\Support\Facades\Storage;

class TodayIsApril14th2022 extends SnapshotScenario
{
	/**
	 * \App\Domain\Testing\Snapshots\Scenarios\TodayIsApril14th2022 constructor
	 *
	 * @param  string  $connectionName
	 * @param  bool  $useSQLiteConnection
	 * @param  string  $diskName
	 * @param  array  $diskSettings
	 */
	public function __construct
	(
		string $connectionName = 'dish_mysql',
		bool $useSQLiteConnection = true,
		string $diskName = 'sqlite_snapshots',
		array $diskSettings = []
	)
	{
		config(["filesystems.disks.{$diskName}" => $diskSettings + [
			'driver' => 'local',
			'root' => storage_path('app/sql/dish_mysql/sqlite/schedules'),
			'visibility' => 'private',
		]]);

		parent::__construct(
			(new DishMySqlSnapshotConnection)->setDatabase($connectionName, $useSQLiteConnection),
			Storage::disk($diskName),
		);
	}

	/**
	 * @return CarbonImmutable
	 */
	public function scenarioStartsAt(): CarbonImmutable
	{
		return carbonImmutable('2022-04-14');
	}

	/**
	 * @return CarbonImmutable
	 */
	public function scenarioEndsAt(): CarbonImmutable
	{
		return carbonImmutable('2023-04-14');
	}

	/**
	 * @return IDatabaseSnapshot[]
	 */
	protected function getSnapshots(): array
	{
		return [
			AllValidFromApril14th2022toAugust31st2022::class
		];
	}
}

<?php

namespace App\Domain\Testing\Snapshots\AllSchedulesAreValid;

use App\Domain\Testing\Snapshots\IDatabaseSnapshot;
use App\Domain\Testing\Snapshots\ISnapshotConnection;
use Carbon\CarbonInterface;

class April14ToAugust31StartingIn2022 implements IDatabaseSnapshot
{
	/**
	 * @return string
	 */
	public function getDirectoryPath(): string
	{
		return storage_path('app/sql/dish_mysql/sqlite');
	}

	/**
	 * @return string
	 */
	public function getFilename(): string
	{
		return 'only_valid_schedules_for_04142022_to_08312022_executions_mysql.sqlite';
	}

	/**
	 * @return string
	 */
	public function getSnapshotAlias(): string
	{
		return static::class;
	}

	/**
	 * @return CarbonInterface
	 */
	public function dataEndsOn(): CarbonInterface
	{
		return carbonImmutable('2022-08-31');
	}

	/**
	 * @return CarbonInterface
	 */
	public function dataStartsOn(): CarbonInterface
	{
		return carbonImmutable('2022-04-14');
	}

	/**
	 * @return int
	 */
	public function totalRecordsValid(): int
	{
		return $this->dataStartsOn()->daysUntil($this->dataEndsOn())->count();
	}

	/**
	 * @return int
	 */
	public function totalRecordsInvalid(): int
	{
		return $this->dataStartsOn()->daysInYear - $this->totalRecordsValid();
	}

	/**
	 * @param  ISnapshotConnection  $connection
	 * @param  bool  $refreshDatabase
	 *
	 * @return static
	 */
	public function applyDatabaseState(ISnapshotConnection $connection, bool $refreshDatabase = false): static
	{
		// TODO: Implement applyDatabaseState() method.
	}

	/**
	 * Not applicable
	 *
	 * @param  ISnapshotConnection  $snapshotConnection
	 *
	 * @return void
	 */
	public function runSQLDump(ISnapshotConnection $snapshotConnection): void
	{
		//
	}
}

<?php

namespace App\Domain\Testing\Snapshots\AllSchedulesAreValid;

use App\Domain\Testing\Snapshots\IDatabaseSnapshot;
use App\Domain\Testing\Snapshots\ISnapshotConnection;
use App\Domain\Testing\Snapshots\Scenarios\SnapshotScenario;
use App\Domain\Testing\Snapshots\Scenarios\TodayIsApril14th2022;
use App\Models\Execution;
use App\Models\QueryBuilders\ExecutionQueryBuilder;
use Carbon\CarbonInterface;

class April14ToApril14StartingIn2022 implements IDatabaseSnapshot
{
	protected SnapshotScenario $scenario;

	public function __construct()
	{
		$this->scenario = new TodayIsApril14th2022;
	}

	/**
	 * @return string
	 */
	public function getDirectoryPath(): string
	{
		return storage_path('app/sql/dish_mysql/sqlite/schedules');
	}

	/**
	 * @return string
	 */
	public function getFilename(): string
	{
		return 'all_year_is_valid_from_04142022_to_04142023_executions_mysql.sqlite';
	}

	/**
	 * @return string
	 */
	public function getSnapshotAlias(): string
	{
		return static::class;
	}

	/**
	 * @return CarbonInterface
	 */
	public function dataEndsOn(): CarbonInterface
	{
		return carbonImmutable('2022-08-31');
	}

	/**
	 * @return CarbonInterface
	 */
	public function dataStartsOn(): CarbonInterface
	{
		return carbonImmutable('2022-04-14');
	}

	/**
	 * @return int
	 */
	public function totalRecordsValid(): int
	{
		return $this->dataStartsOn()->daysUntil($this->dataEndsOn())->count();
	}

	/**
	 * @return int
	 */
	public function totalRecordsInvalid(): int
	{
		return $this->dataStartsOn()->daysInYear - $this->totalRecordsValid();
	}

	/**
	 * @param  ISnapshotConnection  $connection
	 * @param  bool  $refreshDatabase
	 *
	 * @return static
	 */
	public function applyDatabaseState(ISnapshotConnection $connection, bool $refreshDatabase = false): static
	{
		$connection->refreshConnection($this);

		$totalWithValidSchedule = $this->whereHasValidSchedule()->count();

		if (Execution::count() === $totalWithValidSchedule &&
			$this->scenario->getTotalDays() >= $totalWithValidSchedule) {
			# This is already the current DB state
			return $this;
		}

		if ($refreshDatabase) {
			$this->scenario->getSnapshotConnection()->refreshDatabase();
		}

		$this->scenario->applySnapshotData($this);

		return $this;
	}

	/**
	 * @return ExecutionQueryBuilder
	 */
	public function whereHasValidSchedule(): ExecutionQueryBuilder
	{
		return Execution::query()
			->whereBetween(Execution::SCHEDULING_DATE, [$this->dataStartsOn(), $this->dataEndsOn()])
			->whereHasFilledSchedulingResults();
	}

	/**
	 * Not applicable
	 *
	 * @param  ISnapshotConnection  $snapshotConnection
	 *
	 * @return void
	 */
	public function runSQLDump(ISnapshotConnection $snapshotConnection): void
	{
		//
	}
}

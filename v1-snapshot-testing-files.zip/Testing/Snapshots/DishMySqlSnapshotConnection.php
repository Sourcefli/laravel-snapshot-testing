<?php

namespace App\Domain\Testing\Snapshots;

use App\Models\Approval;
use App\Models\Execution;
use App\Models\LoggedExecution;
use App\Models\QueueJob;
use Database\Seeders\UserSeeder;
use Illuminate\Database\Connection;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Database\Console\Migrations\FreshCommand;
use Illuminate\Database\Schema\Builder;
use Illuminate\Database\SQLiteConnection;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Str;
use RuntimeException;

class DishMySqlSnapshotConnection implements ISnapshotConnection
{
	private ConnectionInterface|Connection $connection;
	private bool $usesSQLiteConnection = true;

	/**
	 * @return void
	 */
	private function migrateTestDatabase(?array $existingTables = null)
	{
		if ($this->usesSQLiteConnection && ! $this->connection instanceof SQLiteConnection) {
			return;
		}

		$existingTables = $existingTables ?? method_exists($this->connection->query(), 'getTables') ? $this->connection->query()->getTables() : throw new RuntimeException("Unable to determine ");

		if (method_exists($this->connection->query(), 'getTables') &&
			$this->connection->query()->getTables()->isNotEmpty()) {
			return;
		}

		Artisan::call(FreshCommand::class, [
			'--database' => $this->connection->getName(),
			'--seed' => true,
			'--seeder' => UserSeeder::class
		]);
	}

	/**
	 * @return ConnectionInterface
	 */
	public function getDatabase(): ConnectionInterface
	{
		return $this->connection;
	}

	/**
	 * @return static
	 */
	public function refreshDatabase(): static
	{
		$this->migrateTestDatabase();

		$tableCounts = [
			Approval::TABLE => Approval::count(),
			LoggedExecution::TABLE => LoggedExecution::count(),
			Execution::TABLE => Execution::count(),
			QueueJob::TABLE => QueueJob::count(),
			'failed_jobs' => $this->connection->table('failed_jobs')->count(),
			'job_batches' => $this->connection->table('job_batches')->count(),
		];

		$this->getSchema()->disableForeignKeyConstraints();

		foreach ($tableCounts as $table => $count) {
			if (! $count) {
				continue;
			}

			$this->connection->table($table)->truncate();
		}

		$this->getSchema()->enableForeignKeyConstraints();

		return $this;
	}

	/**
	 * In case the underlying 'dish_mysql' connection gets swapped out while a test is being executed
	 *
	 * @param  IDatabaseSnapshot  $databaseSnapshot
	 *
	 * @return static
	 */
	public function refreshConnection(IDatabaseSnapshot $databaseSnapshot): static
	{
		if (str_ends_with($databaseSnapshot->getFilename(), '.sqlite')) {
			$this->useSQLiteConnection($databaseSnapshot->getFilename());
		}

		$databaseSnapshot->runSQLDump($this);

		if ($this->connection->getDatabaseName() !== DB::connection($name = $this->connection->getName())->getDatabaseName()) {
			DB::purge($name);

			$this->connection = DB::connection($name);
		}

		return $this;
	}

	/**
	 * @param  string|ConnectionInterface  $connection
	 * @param  bool  $isSQLiteConnection
	 *
	 * @return static
	 */
	public function setDatabase(string|ConnectionInterface $connection, bool $isSQLiteConnection = true): static
	{
		$this->connection = is_string($connection) ? DB::connection($connection) : $connection;

		$this->usesSQLiteConnection = $isSQLiteConnection;

		return $this;
	}

	/**
	 * @param  string  $sqliteFilePath
	 *
	 * @return void
	 */
	public function useSQLiteConnection(string $sqliteFilePath): void
	{
		$settings = [
			...config('database.connections.sqlite'),
			'database' => $sqliteFilePath
		];

		$connectionName = $this->connection->getName();

		if (config("database.connections.{$connectionName}.database", Str::random(5)) === data_get($settings, 'database')) {
			return;
		}

		config([
			"database.connections.{$connectionName}" => $settings
		]);

		DB::purge($connectionName);

		$this->refreshConnection();
	}

	public function usesSQLDumpFiles(): bool
	{
		// TODO: Implement usesSQLDumpFiles() method.
	}

	/**
	 * @return Builder
	 */
	public function getSchema(): Builder
	{
		return Schema::connection($this->connection->getName());
	}
}

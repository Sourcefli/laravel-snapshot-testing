<?php

namespace App\Domain\Testing\DishMySql;

use App\Actions\UplinkEvents\GetCurrentClosestDateWithNoUplinkEvents;
use App\Domain\Testing\Snapshots\Scenarios\TodayIsApril14th2022;
use App\Models\Execution;
use Carbon\CarbonImmutable;
use Illuminate\Contracts\Container\BindingResolutionException;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Database\Connection;
use Illuminate\Database\Query\Builder;
use Illuminate\Filesystem\FilesystemAdapter;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use InvalidArgumentException;
use JetBrains\PhpStorm\ArrayShape;
use RuntimeException;

class SnapshotRepository
{
	public readonly string $diskName;

	public readonly string $testEndDate;

	public readonly string $testStartDate;

	protected Connection $connection;

	protected string $currentClosestDateWithNoEvents = "2021-01-02";

	protected Filesystem|FilesystemAdapter $disk;

	private array $currentSnapshotConfig;

	private array $testDates = [
		TodayIsApril14th2022::class
	];

	/**
	 * 'partial_range' meaning that some rows will be missing
	 *  within the entire date range being tested
	 *
	 * @var array|\array[][]
	 */
	private array $snapshotConfigurations = [
		'valid_schedules.partial_range' => [
			[
				'alias' => 'valid_schedules_only.1',
				'filename' => 'only_valid_schedules_for_04142022_to_08312022_executions_mysql.sqlite',
				'dbExecutionsStartAt' => '2022-04-14',
				'dbExecutionsEndAt' => '2022-08-31',
				'totalValidExecutionCount' => 140,
				'expectedStartDate' => '2022-09-01',
				'expectedEndDate' => [self::class, 'resolveCurrentClosestDateWithNoEvents'],
			],
		],
		'valid_schedules.entire_range' => [
			[
				'alias' => 'has_entirely_valid_schedules.1',
				'filename' => 'first_date_not_having_uplinkevents_before_0423.sqlite',
				'dbExecutionsStartAt' => '2022-04-14',
				'dbExecutionsEndAt' => [self::class, 'resolveCurrentClosestDateWithNoEvents'],
				'expectedStartDate' => [self::class, 'resolveCurrentClosestDateWithNoEvents'],
				'expectedEndDate' => [self::class, 'resolveCurrentClosestDateWithNoEvents'],
			],
		],
		'null_schedules.partial_range' => [
			[
				'alias' => 'has_null_schedules.1',
				'filename' => 'first_null_date_between_0422_and_0822.sqlite',
				'dbExecutionsStartAt' => '2022-04-14',
				'dbExecutionsEndAt' => '2022-08-31',
				'expectedStartDate' => '2022-07-30',
				'expectedEndDate' => [self::class, 'resolveCurrentClosestDateWithNoEvents'],
			],
		],
		'negated_schedules.partial_range' => [
			[
				'alias' => 'has_negated_schedules.1',
				'filename' => 'first_negated_date_between_0422_and_0822.sqlite',
				'dbExecutionsStartAt' => '2022-04-14',
				'dbExecutionsEndAt' => '2022-08-31',
				'expectedStartDate' => '2022-04-25',
				'expectedEndDate' => [self::class, 'resolveCurrentClosestDateWithNoEvents'],
			],
		],
	];

	/**
	 * Has valid and null schedules within date range
	 *
	 * @param  bool  $purgeMySqlDb
	 *
	 */
	public function insertValidAndNullSchedulesFromApril22ToApril23(bool $purgeMySqlDb = true)
	{
		$this->refreshConnection();

		if ($purgeMySqlDb) {
			$this->purgeDb();
		}

		$this->connection->unprepared(
			$this->disk->get(
				'sql/dish_mysql/unzipped/valid_and_null_schedules_for_041422_to_04314023_executions_mysql.sql'
			)
		);
	}

	/**
	 * Has valid and null schedules within date range.
	 *
	 * @param  string  $fileOrAlias
	 * @param  bool  $purgeMySqlDb
	 */
	public function useValidSchedulesPartialRangeSnapshot(string $fileOrAlias, bool $purgeMySqlDb = true)
	{
		$this->useSnapshot('valid_schedules.partial_range', $fileOrAlias);

		$this->refreshConnection();

		$snapshotConfig = $this->getCurrentSnapshotConfig();

		$totalValidExecutionCount = $snapshotConfig['totalValidExecutionCount'];

		$totalWithValidSchedule = Execution::query()
			->whereBetween(Execution::SCHEDULING_DATE, $this->getDateExpectations())
			->whereHasFilledSchedulingResults()
			->count();

		if (Execution::count() === $totalValidExecutionCount &&
			$totalValidExecutionCount >= $totalWithValidSchedule) {
			# This is already the current DB state, no need to re-run the SQL file
			return;
		}

		if ($purgeMySqlDb) {
			$this->purgeDb();
		}

		$this->connection->unprepared(
			$this->disk->get($snapshotConfig['filename'])
		);
	}

	/**
	 * Has valid and null schedules within date range
	 *
	 * @param  string  $fileOrAlias
	 * @param  bool  $purgeMySqlDb
	 */
	public function useNullSchedulesPartialRangeSnapshot(string $fileOrAlias, bool $purgeMySqlDb = true)
	{
		$this->useSnapshot('null_schedules.partial_range', $fileOrAlias);

		$this->refreshConnection();

		[$start, $end] = $this->getDateExpectations();

		$totalWithValidSchedule = Execution::query()
			->whereBetween(Execution::SCHEDULING_DATE, [$start, $end])
			->whereHasFilledSchedulingResults()
			->count();

		$totalWithNullSchedule = Execution::query()
			->whereBetween(Execution::SCHEDULING_DATE, [$start, $end])
			->whereHasInvalidatedSchedulingResults()
			->count();

		$totalValidDays = ($start->daysUntil($end)->count() - $totalWithNullSchedule);

		if (Execution::count() === ($totalWithValidSchedule + $totalWithNullSchedule) &&
			$totalValidDays === $totalWithValidSchedule) {
			# This is already the current DB state, no need to re-run the SQL file
			return;
		}

		if ($purgeMySqlDb) {
			$this->purgeDb();
		}

		$this->connection->unprepared(
			$this->disk->get($this->getCurrentSnapshotConfig('filename'))
		);
	}

	/**
	 * Has valid and null schedules within date range
	 *
	 * @param  bool  $purgeMySqlDb
	 *
	 */
	public function insertSpottedNegationsFromApril22ToAug22(bool $purgeMySqlDb = true)
	{
		$this->refreshConnection();

		$start = carbonImmutable('2022-04-14');
		$end = carbonImmutable('2022-08-31');

		$totalWithValidSchedule = Execution::query()
			->whereBetween(Execution::SCHEDULING_DATE, [$start, $end])
			->whereHasFilledSchedulingResults()
			->count();

		$totalWithNegatedSchedule = Execution::query()
			->whereBetween(Execution::SCHEDULING_DATE, [$start, $end])
			->whereNotNull(Execution::NEGATION_TYPE)
			->count();

		$totalValidDays = ($start->daysUntil($end)->count() - $totalWithNegatedSchedule);

		if (Execution::count() === ($totalWithValidSchedule + $totalWithNegatedSchedule) &&
			$totalValidDays === $totalWithValidSchedule) {
			# This is already the current DB state, no need to re-run the SQL file
			return;
		}

		if ($purgeMySqlDb) {
			$this->purgeDb();
		}

		$this->connection->unprepared(
			$this->disk->get(
				"sql/dish_mysql/unzipped/spotted_negations_with_null_and_valid_schedules_for_{$start->format('mdY')}_to_{$end->format('mdY')}_executions_mysql.sql"
			)
		);
	}

	/**
	 * @param  bool  $purgeMySqlDb
	 *
	 */
	public function insertValidForEntireYearFromApril22ToApril23(bool $purgeMySqlDb = true)
	{

	}

	/**
	 * @return Connection
	 */
	public function getConnection(): Connection
	{
		return $this->connection;
	}

	/**
	 * @param  string  $fileOrAlias
	 *
	 * @return CarbonImmutable
	 *
	 */
	public function getExpectedStartDateForSnapShot(string $category, string $fileOrAlias): CarbonImmutable
	{
		//@formatter:off
		return carbonImmutable($this->getSnapshotConfig($category, $fileOrAlias)['expectedStartDate']);
	}

	/**
	 * @return Builder
	 */
	protected function getExecutionsBuilder(): Builder
	{
		return $this->connection->table('executions');
	}

	public function useSnapshot(string $snapshotClass): static
	{
//		$this->sna
	}

//	/**
//	* @param string $category
//	* @param  string  $fileOrAlias
//	*
//	* @return static
//	*/
//	public function useSnapshot(string $category, string $fileOrAlias): static
//	{
//		$config = $this->getSnapshotConfig($category, $fileOrAlias);
//
//		if (! is_array($config) || ! $this->disk->fileExists($config['filename'])) {
//			throw new InvalidArgumentException("No snapshot config could be found for category [{$fileOrAlias}] using file or alias [{$fileOrAlias}]");
//		}
//
//		$this->setCurrentSnapshotConfig($config);
//
//		$this->useSQLiteConnection($this->disk->path($fileOrAlias));
//
//		return $this;
//	}

	/**
	 * @param bool $useQuery
	 *
	 * @return CarbonImmutable|null
	 *
	 * @throws BindingResolutionException
	 */
	public function resolveCurrentClosestDateWithNoEvents(bool $useQuery = false): ?CarbonImmutable
	{
		if (! $useQuery) {
			# Will change as time goes on, but efficient
			return carbonImmutable($this->currentClosestDateWithNoEvents);
		}

		# Will always return correct date as time goes on, but not as efficient
		return GetCurrentClosestDateWithNoUplinkEvents::run($this->getTestingStartDate(), $this->getTestingEndDate());
	}

	/**
	 * @param  string  $connectionName
	 *
	 * @return static
	 */
	public function setConnection(string $connectionName): static
	{
		$this->connection = DB::connection($connectionName);

		return $this;
	}

	/**
	 * @param  array  $settings
	 */
	public function setDisk(array $settings = [])
	{
		config(["filesystems.disks.{$this->diskName}" => $settings + [
			'driver' => 'local',
			'root' => storage_path('app/sql/dish_mysql/sqlite'),
			'visibility' => 'private',
		]]);

		$this->disk = Storage::disk($this->diskName);
	}

	/**
	* @param array $snapshotConfig
	*
	* @return SnapshotRepository
	*/
	public function setCurrentSnapshotConfig(array $snapshotConfig): static
	{
    	$this->currentSnapshotConfig = $snapshotConfig;

		return $this;
	}

	/**
	* @return array
	*/
	#[ArrayShape([
		'alias' => 'string',
		'filename' => 'string',
		'dbExecutionsStartAt' => 'string',
		'dbExecutionsEndAt' => 'string',
		'totalValidExecutionCount' => 'integer',
		'expectedStartDate' => 'string',
		'expectedEndDate' => 'callable|string',
	])]
	public  function getCurrentSnapshotConfig(?string $attribute = null): array
	{
		return $this->currentSnapshotConfig[$attribute] ?? $this->currentSnapshotConfig;
	}

	/**
	* @return CarbonImmutable
	*/
	public function getTestingStartDate():CarbonImmutable
	{
		return carbonImmutable($this->testStartDate);
	}

	/**
	* @return CarbonImmutable
	*/
	public function getTestingEndDate():CarbonImmutable
	{
		return carbonImmutable($this->testEndDate);
	}

	/**
	* @param string $category
	* @param string $fileOrAlias
	* @param string|null $attribute
	*
	* @return string|array|CarbonImmutable
	*/
	public function getSnapshotConfig(string $category, string $fileOrAlias, string $attribute = null): CarbonImmutable|array|string
	{
		if (! Arr::exists($this->snapshotConfigurations, $category)) {
			throw new InvalidArgumentException("No snapshot category exists named [{$category}]");
		}

		$config = Arr::first($this->snapshotConfigurations[$category],
			fn ($snapshotInfo) => $snapshotInfo['alias'] === $fileOrAlias || $snapshotInfo['filename'] === $fileOrAlias
		);

		if( ! $attribute) {
			return $config;
		}

		return value($config[$attribute] ?? null);
	}

	/**
	 * @return array<CarbonImmutable, CarbonImmutable>
	 */
	public function getDateExpectations(): array
	{
		$this->enforceCurrentConfiguration();

		return [
			\carbonImmutable($this->getCurrentSnapshotConfig()['expectedStartDate']),
			\carbonImmutable($this->getCurrentSnapshotConfig()['expectedEndDate'])
		];
	}

	/**
	* @return void
	*/
	protected function enforceCurrentConfiguration(): void
	{
		if (! isset($this->currentSnapshotConfig)) {
			throw new RuntimeException("No snapshot configuration has been set");
		}
	}
}

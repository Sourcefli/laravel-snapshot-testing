<?php

namespace App\Domain\Testing\DishMySql;

use App\Domain\Testing\Snapshots\Scenarios\SnapshotScenario;
use App\Domain\Testing\Snapshots\Scenarios\TodayIsApril14th2022;
use Carbon\CarbonInterface;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\Date;

class SnapshotFactory
{
	private static array $testDates = [
		TodayIsApril14th2022::class
	];

	/**
	 * @param  CarbonInterface  $date
	 *
	 * @return SnapshotScenario
	 */
	public static function whenTodayIs(CarbonInterface $date): SnapshotScenario
	{
		$scenario = Arr::first(self::$testDates,
			fn (string $scenario) => app($scenario)->scenarioStartsAt()->isSameDay($date)
		);

		Date::setTestNow($scenario->scenarioStartsAt());

		return $scenario;
	}
}

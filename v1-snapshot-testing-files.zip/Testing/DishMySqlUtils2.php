<?php

namespace App\Domain\Testing;

use App\Models\Approval;
use App\Models\Execution;
use App\Models\LoggedExecution;
use App\Models\QueueJob;
use Carbon\CarbonImmutable;
use Database\Seeders\UserSeeder;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Database\Connection;
use Illuminate\Database\Console\Migrations\FreshCommand;
use Illuminate\Database\Query\Builder;
use Illuminate\Database\SQLiteConnection;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Storage;

class DishMySqlUtils2
{
	protected Connection $connection;
	protected Builder $tableBuilder;
	protected Filesystem $disk;

	public function __construct()
	{
		$this->connection = DB::connection('dish_mysql');
		$this->disk = Storage::disk('local');
	}

	/**
	 * Has valid and null schedules within date range
	 *
	 * @param  bool  $purgeMySqlDb
	 *
	 */
	public function insertValidAndNullSchedulesFromApril22ToApril23(bool $purgeMySqlDb = true)
	{
		$this->refreshConnection();

		if ($purgeMySqlDb) {
			$this->purgeDishMySql();
		}

		$this->connection->unprepared(
			$this->disk->get(
				'sql/dish_mysql/unzipped/valid_and_null_schedules_for_041422_to_04314023_executions_mysql.sql'
			)
		);
	}

	/**
	 * Has valid and null schedules within date range
	 *
	 * @param  bool  $purgeMySqlDb
	 */
	public function insertOnlyValidSchedulesFromApril22ToAug22(bool $purgeMySqlDb = true)
	{
		$this->refreshConnection();

		$start = carbonImmutable('2022-04-14');
		$end = carbonImmutable('2022-08-31');

		# Check if we're already using this DB state
		if(! $this->migrateTestDatabase()) {
			$totalExecutionsInDBSnapshot = 263;
			$totalWithValidSchedule = Execution::query()
				->whereBetween(Execution::SCHEDULING_DATE, [$start, $end])
				->whereHasFilledSchedulingResults()
				->count();

			$totalDays = $start->daysUntil($end)->count();

			if (Execution::count() === $totalWithValidSchedule &&
				$totalDays >= $totalWithValidSchedule) {
				# This is already the current DB state, no need to re-run the SQL file
				return;
			}
		}

		if ($purgeMySqlDb) {
			$this->purgeDishMySql();
		}

		$this->connection->unprepared(
			$this->disk->get(
				"sql/dish_mysql/unzipped/only_valid_schedules_for_{$start->format('mdY')}_to_{$end->format('mdY')}_executions_mysql.sql"
			)
		);
	}

	/**
	 * Has valid and null schedules within date range
	 *
	 * @param  bool  $purgeMySqlDb
	 *
	 */
	public function insertSpottedNullSchedulesFromApril22ToAug22(bool $purgeMySqlDb = true)
	{
		$this->refreshConnection();

		$start = carbonImmutable('2022-04-14');
		$end = carbonImmutable('2022-08-31');

		$totalWithValidSchedule = Execution::query()
			->whereBetween(Execution::SCHEDULING_DATE, [$start, $end])
			->whereHasFilledSchedulingResults()
			->count();

		$totalWithNullSchedule = Execution::query()
			->whereBetween(Execution::SCHEDULING_DATE, [$start, $end])
			->whereHasInvalidatedSchedulingResults()
			->count();

		$totalValidDays = ($start->daysUntil($end)->count() - $totalWithNullSchedule);

		if (Execution::count() === ($totalWithValidSchedule + $totalWithNullSchedule) &&
			$totalValidDays === $totalWithValidSchedule) {
			# This is already the current DB state, no need to re-run the SQL file
			return;
		}

		if ($purgeMySqlDb) {
			$this->purgeDishMySql();
		}

		$this->connection->unprepared(
			$this->disk->get(
				"sql/dish_mysql/unzipped/spotted_null_schedules_for_{$start->format('mdY')}_to_{$end->format('mdY')}_executions_mysql.sql"
			)
		);
	}

	/**
	 * Has valid and null schedules within date range
	 *
	 * @param  bool  $purgeMySqlDb
	 *
	 */
	public function insertSpottedNegationsFromApril22ToAug22(bool $purgeMySqlDb = true)
	{
		$this->refreshConnection();

		$start = carbonImmutable('2022-04-14');
		$end = carbonImmutable('2022-08-31');

		$totalWithValidSchedule = Execution::query()
			->whereBetween(Execution::SCHEDULING_DATE, [$start, $end])
			->whereHasFilledSchedulingResults()
			->count();

		$totalWithNegatedSchedule = Execution::query()
			->whereBetween(Execution::SCHEDULING_DATE, [$start, $end])
			->whereNotNull(Execution::NEGATION_TYPE)
			->count();

		$totalValidDays = ($start->daysUntil($end)->count() - $totalWithNegatedSchedule);

		if (Execution::count() === ($totalWithValidSchedule + $totalWithNegatedSchedule) &&
			$totalValidDays === $totalWithValidSchedule) {
			# This is already the current DB state, no need to re-run the SQL file
			return;
		}

		if ($purgeMySqlDb) {
			$this->purgeDishMySql();
		}

		$this->connection->unprepared(
			$this->disk->get(
				"sql/dish_mysql/unzipped/spotted_negations_with_null_and_valid_schedules_for_{$start->format('mdY')}_to_{$end->format('mdY')}_executions_mysql.sql"
			)
		);
	}

	/**
	 * @param  bool  $purgeMySqlDb
	 *
	 */
	public function insertValidForEntireYearFromApril22ToApril23(bool $purgeMySqlDb = true)
	{
		$this->refreshConnection();

		$start = carbonImmutable('2022-04-14');
		$end = carbonImmutable('2023-04-14');

		$totalWithValidSchedule = Execution::query()
			->whereBetween(Execution::SCHEDULING_DATE, [$start, $end])
			->whereHasFilledSchedulingResults()
			->count();

		$totalValidDays = $start->daysUntil($end)->count();

		if (Execution::count() === $totalWithValidSchedule &&
			$totalValidDays >= $totalWithValidSchedule) {
			# This is already the current DB state, no need to re-run the SQL file
			return;
		}

		if ($purgeMySqlDb) {
			$this->purgeDishMySql();
		}

		$this->connection->unprepared(
			$this->disk->get(
				"sql/dish_mysql/unzipped/all_year_with_valid_schedules_for_{$start->format('mdY')}_to_{$end->format('mdY')}_executions_mysql.sql"
			)
		);
	}

	/**
	 * @return Connection
	 */
	public function getConnection(): Connection
	{
		return $this->connection;
	}

	/**
	 * @param  string  $key
	 *
	 * @return CarbonImmutable
	 */
	public function getExpectedDate(string $key): CarbonImmutable
	{
		return \carbonImmutable([
			'first_null_date_between_0422_and_0822' => '2022-07-30',
			'first_negated_date_between_0422_and_0822' => '2022-04-25',
			'first_non_existing_execution_date_after_083122' => '2022-09-01',
			'date_before_no_uplinkevents_exist_before_0423' => '2023-01-02',
		][$key]);
	}

	/**
	 * @return Builder
	 */
	protected function getExecutionsBuilder(): Builder
	{
		return $this->connection->table('executions');
	}

	/**
	 * In case the underlying 'dish_mysql' connection gets swapped out while a test is executing
	 *
	 * @return static
	 */
	public function refreshConnection(): static
	{
		if ($this->connection->getDatabaseName() === DB::connection($this->connection->getName())->getDatabaseName()) {
			return $this;
		}

		DB::purge('dish_mysql');

		$this->connection = DB::connection('dish_mysql');

		return $this;
	}

	/**
	 * True when newly migrated
	 *
	 * @return bool
	 */
	public function migrateTestDatabase(): bool
	{
		if (! $this->connection instanceof SQLiteConnection) {
			return false;
		}

		if ($this->connection->query()->getTables()->isNotEmpty()) {
			return false;
		}

		Artisan::call(FreshCommand::class, [
			'--database' => $this->connection->getName(),
			'--seed' => true,
			'--seeder' => UserSeeder::class
		]);

		return true;
	}

	/**
	 * @return void
	 */
	public function purgeDishMySql(): void
	{
		if ($this->migrateTestDatabase()) {
			return;
		}

		$tableCounts = [
			Approval::TABLE => Approval::count(),
			LoggedExecution::TABLE => LoggedExecution::count(),
			Execution::TABLE => Execution::count(),
			QueueJob::TABLE => QueueJob::count(),
			'failed_jobs' => $this->connection->table('failed_jobs')->count(),
			'job_batches' => $this->connection->table('job_batches')->count(),
		];

		$this->getSchema()->disableForeignKeyConstraints();

		foreach ($tableCounts as $table => $count) {
			if (! $count) continue;

			$this->connection->table($table)->truncate();
		}

		$this->getSchema()->enableForeignKeyConstraints();
	}

	/**
	 * @return \Illuminate\Database\Schema\Builder
	 */
	protected function getSchema(): \Illuminate\Database\Schema\Builder
	{
		return Schema::connection('dish_mysql');
	}
}

<?php

namespace App\Domain\Testing;

use App\Domain\Testing\DishMySql\SnapshotRepository;
use App\Models\Approval;
use App\Models\Execution;
use App\Models\LoggedExecution;
use App\Models\QueueJob;
use Carbon\CarbonImmutable;
use Database\Seeders\UserSeeder;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Database\Connection;
use Illuminate\Database\Console\Migrations\FreshCommand;
use Illuminate\Database\Query\Builder;
use Illuminate\Database\SQLiteConnection;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Str;

class DishMySqlSeedingUtils
{
	public SnapshotRepository $dishMySqlSnapshots;
	protected Connection $connection;
	protected Builder $tableBuilder;
	protected Filesystem $disk;

	public function __construct()
	{
		$this->dishMySqlSnapshots = new SnapshotRepository;
	}

	/**
	 * Has valid and null schedules within date range
	 *
	 * @param  bool  $purgeMySqlDb
	 *
	 */
	public function insertValidAndNullSchedulesFromApril22ToApril23(bool $purgeMySqlDb = true)
	{
		$this->refreshConnection();

		if ($purgeMySqlDb) {
			$this->purgeDishMySql();
		}

		$this->connection->unprepared(
			$this->disk->get(
				'sql/dish_mysql/unzipped/valid_and_null_schedules_for_041422_to_04314023_executions_mysql.sql'
			)
		);
	}

	/**
	 * Has valid and null schedules within date range
	 *
	 * @param  bool  $purgeMySqlDb
	 */
	public function insertOnlyValidSchedulesFromApril22ToAug22(bool $purgeMySqlDb = true)
	{
		$this->refreshConnection();

		$start = carbonImmutable('2022-04-14');
		$end = carbonImmutable('2022-08-31');

		$totalExecutionsInDBSnapshot = 140;
		$totalWithValidSchedule = Execution::query()
			->whereBetween(Execution::SCHEDULING_DATE, [$start, $end])
			->whereHasFilledSchedulingResults()
			->count();

		if (Execution::count() === $totalExecutionsInDBSnapshot &&
			$totalExecutionsInDBSnapshot >= $totalWithValidSchedule) {
			# This is already the current DB state, no need to re-run the SQL file
			return;
		}

		if ($purgeMySqlDb) {
			$this->purgeDishMySql();
		}

		$this->connection->unprepared(
			$this->disk->get(
				"sql/dish_mysql/unzipped/only_valid_schedules_for_{$start->format('mdY')}_to_{$end->format('mdY')}_executions_mysql.sql"
			)
		);
	}

	/**
	 * Has valid and null schedules within date range
	 *
	 * @param  bool  $purgeMySqlDb
	 *
	 */
	public function insertSpottedNullSchedulesFromApril22ToAug22(bool $purgeMySqlDb = true)
	{
		$this->refreshConnection();

		$start = carbonImmutable('2022-04-14');
		$end = carbonImmutable('2022-08-31');

		$totalWithValidSchedule = Execution::query()
			->whereBetween(Execution::SCHEDULING_DATE, [$start, $end])
			->whereHasFilledSchedulingResults()
			->count();

		$totalWithNullSchedule = Execution::query()
			->whereBetween(Execution::SCHEDULING_DATE, [$start, $end])
			->whereHasInvalidatedSchedulingResults()
			->count();

		$totalValidDays = ($start->daysUntil($end)->count() - $totalWithNullSchedule);

		if (Execution::count() === ($totalWithValidSchedule + $totalWithNullSchedule) &&
			$totalValidDays === $totalWithValidSchedule) {
			# This is already the current DB state, no need to re-run the SQL file
			return;
		}

		if ($purgeMySqlDb) {
			$this->purgeDishMySql();
		}

		$this->connection->unprepared(
			$this->disk->get(
				"sql/dish_mysql/unzipped/spotted_null_schedules_for_{$start->format('mdY')}_to_{$end->format('mdY')}_executions_mysql.sql"
			)
		);
	}

	/**
	 * Has valid and null schedules within date range
	 *
	 * @param  bool  $purgeMySqlDb
	 *
	 */
	public function insertSpottedNegationsFromApril22ToAug22(bool $purgeMySqlDb = true)
	{
		$this->refreshConnection();

		$start = carbonImmutable('2022-04-14');
		$end = carbonImmutable('2022-08-31');

		$totalWithValidSchedule = Execution::query()
			->whereBetween(Execution::SCHEDULING_DATE, [$start, $end])
			->whereHasFilledSchedulingResults()
			->count();

		$totalWithNegatedSchedule = Execution::query()
			->whereBetween(Execution::SCHEDULING_DATE, [$start, $end])
			->whereNotNull(Execution::NEGATION_TYPE)
			->count();

		$totalValidDays = ($start->daysUntil($end)->count() - $totalWithNegatedSchedule);

		if (Execution::count() === ($totalWithValidSchedule + $totalWithNegatedSchedule) &&
			$totalValidDays === $totalWithValidSchedule) {
			# This is already the current DB state, no need to re-run the SQL file
			return;
		}

		if ($purgeMySqlDb) {
			$this->purgeDishMySql();
		}

		$this->connection->unprepared(
			$this->disk->get(
				"sql/dish_mysql/unzipped/spotted_negations_with_null_and_valid_schedules_for_{$start->format('mdY')}_to_{$end->format('mdY')}_executions_mysql.sql"
			)
		);
	}

	/**
	 * @param  bool  $purgeMySqlDb
	 *
	 */
	public function insertValidForEntireYearFromApril22ToApril23(bool $purgeMySqlDb = true)
	{
		$this->refreshConnection();

		$start = carbonImmutable('2022-04-14');
		$end = carbonImmutable('2023-04-14');

		$totalWithValidSchedule = Execution::query()
			->whereBetween(Execution::SCHEDULING_DATE, [$start, $end])
			->whereHasFilledSchedulingResults()
			->count();

		$totalValidDays = $start->daysUntil($end)->count();

		if (Execution::count() === $totalWithValidSchedule &&
			$totalValidDays >= $totalWithValidSchedule) {
			# This is already the current DB state, no need to re-run the SQL file
			return;
		}

		if ($purgeMySqlDb) {
			$this->purgeDishMySql();
		}

		$this->connection->unprepared(
			$this->disk->get(
				"sql/dish_mysql/unzipped/all_year_with_valid_schedules_for_{$start->format('mdY')}_to_{$end->format('mdY')}_executions_mysql.sql"
			)
		);
	}

	/**
	 * @return Connection
	 */
	public function getConnection(): Connection
	{
		return $this->connection;
	}

	/**
	 * @param  string  $key
	 *
	 * @return CarbonImmutable
	 */
	public function getExpectedDate(string $key): CarbonImmutable
	{
		return \carbonImmutable([
			'first_null_date_between_0422_and_0822' => '2022-07-30',
			'first_negated_date_between_0422_and_0822' => '2022-04-25',
			'first_non_existing_execution_date_after_083122' => '2022-09-01',
			'date_before_no_uplinkevents_exist_before_0423' => '2023-01-01',
		][$key]);
	}

	/**
	 * @return Builder
	 */
	protected function getExecutionsBuilder(): Builder
	{
		return $this->connection->table('executions');
	}

	/**
	 * In case the underlying 'dish_mysql' connection gets swapped out while a test is executing
	 *
	 * @return static
	 */
	public function refreshConnection(): static
	{
		if ($this->connection->getDatabaseName() !== DB::connection($this->connection->getName())->getDatabaseName()) {
			DB::purge('dish_mysql');

			$this->connection = DB::connection('dish_mysql');
		}

		$this->migrateTestDatabase();

		return $this;
	}

	public function useSnapshot(string $sqliteFilePath): static
	{
		$pathPrefix = storage_path('app/sql/dish_mysql/sqlite');

		$filePath = str_starts_with(storage_path(), $pathPrefix)
			? $pathPrefix
			: sprintf("%s/%s",
				$pathPrefix,
				str_ends_with($sqliteFilePath, '.sqlite') ? $sqliteFilePath : $sqliteFilePath.'.sqlite'
			);

		$this->useSQLiteConnection($filePath);

		return $this;
	}

	/**
	 * @return void
	 */
	public function purgeDishMySql(): void
	{
		$this->migrateTestDatabase();

		$tableCounts = [
			Approval::TABLE => Approval::count(),
			LoggedExecution::TABLE => LoggedExecution::count(),
			Execution::TABLE => Execution::count(),
			QueueJob::TABLE => QueueJob::count(),
			'failed_jobs' => $this->connection->table('failed_jobs')->count(),
			'job_batches' => $this->connection->table('job_batches')->count(),
		];

		Schema::connection('dish_mysql')->disableForeignKeyConstraints();

		foreach ($tableCounts as $table => $count) {
			if (! $count) continue;

			DB::connection('dish_mysql')->table($table)->truncate();
		}

		Schema::connection('dish_mysql')->enableForeignKeyConstraints();
	}

	private function migrateTestDatabase()
	{
		if (! $this->connection instanceof SQLiteConnection) {
			return;
		}

		if ($this->connection->query()->getTables()->isNotEmpty()) {
			return;
		}

		Artisan::call(FreshCommand::class, [
			'--database' => $this->connection->getName(),
			'--seed' => true,
			'--seeder' => UserSeeder::class
		]);
	}

	private function useSQLiteConnection(string $sqliteFilePath)
	{
		$settings = [
			...config('database.connections.sqlite'),
			'database' => $sqliteFilePath
		];

		if (config('database.connections.dish_mysql.database', Str::random(5)) === data_get($settings, 'database')) {
			return;
		}

		config([
			'database.connections.dish_mysql' => $settings
		]);

		DB::purge('dish_mysql');

		$this->refreshConnection();

		$this->migrateTestDatabase();
	}
}
